-- 2698470's Lua and Manifest Created by Morrenus
-- Kemono_Teatime
-- Created: October 02, 2025 at 11:30:54 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(2698470) -- Kemono_Teatime
-- MAIN APP DEPOTS
addappid(2698471, 1, "95f3343c9904bd90d71885d3b2eb6746835ec58ad09848c91df7260a0c3460cd") -- Depot 2698471
setManifestid(2698471, "1678074384567397989", 1337554736)
-- DLCS WITH DEDICATED DEPOTS
--   (AppID: 3888580)
addappid(3888580)
addappid(3888580, 1, "5db81899667392d2240d375b096693438142e88700954b729101615c9f941c9e") --   - Depot 3888580
setManifestid(3888580, "6869260105400996256", 1399657668)