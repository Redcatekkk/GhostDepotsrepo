-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 2084000 Manifest
-- Name: Shogun Showdown
-- Generated: 2025-06-07 04:36:24
-- Total Depots: 3
-- Total DLCs: 0 (1 excluded)

-- MAIN APPLICATION
addappid(2084000) -- Shogun Showdown

-- MAIN APP DEPOTS
addappid(2084001, 1, "e467a1dc28688a4ba159328e3419a2ddbbc265d7677b0eff56c56d25954271a9") -- Main Game Content (Windows Content)
setManifestid(2084001, "3630973823110549307", 0)
addappid(2084002, 1, "c1e765cd79523f2e2e0b9b808de03b6a05d66412826feef443a6dfb427f5e80b") -- Game Content (Linux Binaries)
setManifestid(2084002, "5092188064288801929", 0)
addappid(2084003, 1, "7cb9a4ecc6751d163d9efe97d790a2b4f66bcab785782e1dd0791ecb91592bae") -- Game Content (Mac Content)
setManifestid(2084003, "7887161388726160328", 0)

-- DLCS EXCLUDED (NO DEPOT KEYS, NO DEDICATED DEPOTS)
-- addappid(3132940) -- Shogun Showdown Soundtrack (no keys available)
