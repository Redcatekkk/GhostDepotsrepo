-- 248170's Lua and Manifest Created by Morrenus
-- Clickteam Fusion 2.5
-- Created: September 29, 2025 at 04:32:15 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 11
-- Total DLCs: 7 (2 excluded)

-- MAIN APPLICATION
addappid(248170) -- Clickteam Fusion 2.5
-- MAIN APP DEPOTS
addappid(248171, 1, "160eaeceeeb3e7a29932ff1c1e6953c53d75bd693ddc46274bf93eb11dfc654f") -- Program files
setManifestid(248171, "5979420574992650831", 109473405)
addappid(248172, 1, "0efda0c9d0807135964f0efbb83b8c1b577067a26042a7ed3c3900ce76160916") -- Graphic library
setManifestid(248172, "2808615189290196749", 311290276)
addappid(248173, 1, "104f372d486a9c909c3187d0323aaabe7c9331c233889dafe9e4ec601f8ea79a") -- Sound library
setManifestid(248173, "7390804288553202310", 106560144)
addappid(248174, 1, "c99607630f744e98545a9dad2b478218605e2cf1cc4091c720937974f32f96c1") -- Examples
setManifestid(248174, "6703658417066786042", 57147427)
-- DLCS WITH DEDICATED DEPOTS
-- Android Exporter for Clickteam Fusion 2.5 (AppID: 267650)
addappid(267650)
addappid(267650, 1, "46a022be034edc74cc4cf0d7c6588c2fef96c74c580e68e526ff37b2589f7ae8") -- Android Exporter for Clickteam Fusion 2.5 - Android Exporter for Clickteam Fusion 2.5 (267650) Depot
setManifestid(267650, "3219593403311571238", 75003803)
-- iOS Exporter for Clickteam Fusion 2.5 (AppID: 267651)
addappid(267651)
addappid(267651, 1, "4694759f2e0562b9aac6cbb3c2c194845f833c6f130ddfb15efd4a5327676390") -- iOS Exporter for Clickteam Fusion 2.5 - iOS Exporter for Clickteam Fusion 2.5 (267651) Depot
setManifestid(267651, "2556676458812484592", 47877932)
-- HTML5 Exporter for Clickteam Fusion 2.5 (AppID: 267652)
addappid(267652)
addappid(267652, 1, "d3a897396a2197b5e91043999067882126bf899959381f80826210870894cfc3") -- HTML5 Exporter for Clickteam Fusion 2.5 - HTML5 Exporter for Clickteam Fusion 2.5 (267652) Depot
setManifestid(267652, "966052398975222512", 14942832)
-- UWP Exporter for Clickteam Fusion 2.5 (AppID: 267654)
addappid(267654)
addappid(267654, 1, "dd80d595c9f82f85313b846fd98475a148a4b6a75ce8b06bbe0977e48d2cb0bb") -- UWP Exporter for Clickteam Fusion 2.5 - UWP Exporter for Clickteam Fusion 2.5 (267654) Depot
setManifestid(267654, "5783027138609024425", 9740204)
-- Firefly (AppID: 267655)
addappid(267655)
addappid(267655, 1, "bad266bf79c9d1dccbad21c7a8d509964027aa96ee05d0c02050307f2927da7b") -- Firefly - Dépôt : Firefly (267655)
setManifestid(267655, "4332677043085659267", 78132526)
-- Clickteam Fusion 2.5 Developer Upgrade (AppID: 267810)
addappid(267810)
addappid(267810, 1, "8f9fc3fc57221ecac14b8dfcb6bf3ace0fb96cc9385dd0928956d1a518c444c9") -- Clickteam Fusion 2.5 Developer Upgrade - Clickteam Fusion 2.5 Developer Upgrade (267810) Depot
setManifestid(267810, "6964525532638981713", 106433034)
-- Clickteam Fusion 2.5 Addon (AppID: 1056780)
addappid(1056780)
addappid(1056780, 1, "2ba04f3befe99cdc52d6eedf6a1f9b51397bba2396f2ac972ab8b3e5871046dc") -- Clickteam Fusion 2.5 Addon - Dépôt : Clickteam Fusion 2.5+ Addon (1056780)
setManifestid(1056780, "6493421524160028853", 1341884)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Flash Exporter for Clickteam Fusion 2.5 (AppID: 267653) - missing depot keys
-- addappid(267653)
-- Mac Exporter (AppID: 574330) - missing depot keys
-- addappid(574330)