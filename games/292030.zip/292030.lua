-- 292030's Lua and Manifest Created by Morrenus
-- The Witcher 3: Wild Hunt
-- Created: October 01, 2025 at 01:23:10 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 57
-- Total DLCs: 19
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(292030, 1, "9cee38a2013555e62de550c2d53e86dd747dd60d6ca81fda65ff7711d517e322") -- The Witcher 3: Wild Hunt
-- MAIN APP DEPOTS
addappid(292031, 1, "57538aae18fccf308ea67da213c57b2635d53d14b59ade4ebb068dca33328eee") -- The Witcher 3 Content
setManifestid(292031, "1714062795524118335", 38795164504)
addappid(292032, 1, "f6f8cb024f592fa85a1e86523011ed889893386f235624a5a76e12428be6fbac") -- The Witcher 3 x64 Windows Binaries
setManifestid(292032, "3490723872095446153", 367553355)
addappid(292034, 1, "876688c365d3ed8b11a0c1454d8e64234a22dde3e7798ca8e2aa70d55ad5082b") -- The Witcher 3 Uncensored Metadata Store
setManifestid(292034, "8082988454426507412", 60211486)
addappid(292035, 1, "a29f657f2ef95293a55076c120ac3814e8145c1253455c6eb162bf8f03aeb705") -- The Witcher 3 Speech PL
setManifestid(292035, "5593726038514618994", 2649810401)
addappid(292036, 1, "a382ab2faaacad1573c079e6ce74400decd37e6e1a388d67ca242a3aa7af8e0c") -- The Witcher 3 Speech EN
setManifestid(292036, "3491360665020245284", 2715240344)
addappid(292037, 1, "9d4d27d17de980de7a96d2a810f649f2195deeb47ac6aae8f31ca09e17543581") -- The Witcher 3 Speech DE
setManifestid(292037, "3817923221097690740", 2767688055)
addappid(292038, 1, "1b451418b38bac4816cbb838bc7fe6e9273a6228f4498e86c4ed54a0ab9a1156") -- The Witcher 3 Speech FR
setManifestid(292038, "1227805940310364169", 2619989931)
addappid(292039, 1, "2625b539cdd037cdf02cc7a414ce0d12fa3f1266653e97303319ec472c7875fe") -- The Witcher 3 Speech RU
setManifestid(292039, "5480433155299939110", 2885663640)
addappid(292040, 1, "ce852c61d460e3e716ca8e755d1e1485bb467944f96c8b0509fae32f9b2a6392") -- The Witcher 3 Speech JP
setManifestid(292040, "8125275595906123923", 2821809559)
addappid(292041, 1, "7dbc791cd60110b1d08e49d871b15d2356ce70224ca7d950b3ea36617cfbe8bb") -- The Witcher 3 Speech BR
setManifestid(292041, "4823902935523134760", 2733063464)
addappid(292042, 1, "47e959135bc89e032628b3ed3a21c3cd18719d5e111c8489f131d0b166422995") -- The Witcher 3 Exe
setManifestid(292042, "99458089550221039", 176847360)
addappid(292033, 1, "11b857e28f6db3a43762d6756bfb09d701c922ec27ea12cbb8bad1104a184466") -- The Witcher 3 Art Pack
setManifestid(292033, "5639169236463762487", 4439952978)
addappid(370007, 1, "e501823568fd98483bacffd2f32510ba9aabaf2d012ff8e9f8280eedfbd4986c") -- Depot 370007
setManifestid(370007, "6165918066648822292", 2759502865)
addappid(370008, 1, "dba9227ccbfd4748acec6b60fa6cc450ff9303df51c1d319c9c0ac8d87000798") -- Depot 370008
setManifestid(370008, "3305949701387885154", 2859374189)
addappid(370009, 1, "2b8ebd860f519578e0269e5b20a1ce13d76652bd066501087b6c3c1f77f5efc8") -- Depot 370009
setManifestid(370009, "3498696915194240584", 661463668)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- The Witcher 3 Wild Hunt - Temerian Armor Set (AppID: 370000)
addappid(370000)
addtoken(370000, "662041442504756376")
addappid(370000, 1, "cc779551805a59df011c692726377ef65f9505362d482c96df5387856f3ea584") -- The Witcher 3 Wild Hunt - Temerian Armor Set - The Witcher 3: Wild Hunt - Temerian Armor Set (370000) Depot
setManifestid(370000, "1458194560961361295", 64389156)
-- The Witcher 3 Wild Hunt - Beard and Hairstyle Set (AppID: 370001)
addappid(370001)
addappid(370001, 1, "62f05882d6c750c73e7dbb09c38b4107aa9791f63bc847800ce8b8cb90aa0231") -- The Witcher 3 Wild Hunt - Beard and Hairstyle Set - The Witcher 3: Wild Hunt - Beard and Hairstyle Set (370001) Depot
setManifestid(370001, "5979725543926398369", 19244721)
-- The Witcher 3 Wild Hunt - Alternative Look for Yennefer (AppID: 370002)
addappid(370002)
addappid(370002, 1, "a66d950990c695f3297c531ceaffcf6ac5ff949761132dd280943e8dcebeb8f8") -- The Witcher 3 Wild Hunt - Alternative Look for Yennefer - The Witcher 3: Wild Hunt - Alternative Look for Yennefer (370002) Depot
setManifestid(370002, "484236434286524845", 17306453)
-- The Witcher 3 Wild Hunt - New Quest Contract Missing Miners (AppID: 370003)
addappid(370003)
addappid(370003, 1, "26138bf02e93588cd63346a8f3bb943ab5080c7bb71e1f7b4058afd57bb90f23") -- The Witcher 3 Wild Hunt - New Quest Contract Missing Miners - The Witcher 3: Wild Hunt - Contract: Missing Miners (370003) Depot
setManifestid(370003, "5453197123234356101", 33423809)
-- The Witcher 3 Wild Hunt - Nilfgaardian Armor Set (AppID: 373950)
addappid(373950)
addappid(373950, 1, "5c927c7af29a8d017b12cfd585b32987a0934ef7c4a6bc15564ea70846d0df83") -- The Witcher 3 Wild Hunt - Nilfgaardian Armor Set - The Witcher 3: Wild Hunt - Nilfgaardian Armor Set (373950) Depot
setManifestid(373950, "7457326912183925734", 62676877)
-- The Witcher 3 Wild Hunt - Elite Crossbow Set (AppID: 373951)
addappid(373951)
addappid(373951, 1, "d94415a879eb6f7eb0bd2c382900fc1cc57afd85f4e7a7a3f91d17b184bc8d7a") -- The Witcher 3 Wild Hunt - Elite Crossbow Set - The Witcher 3: Wild Hunt - Elite Crossbow Set (373951) Depot
setManifestid(373951, "1015260686331095979", 5832244)
-- The Witcher 3 Wild Hunt - New Quest Fools Gold (AppID: 376390)
addappid(376390)
addappid(376390, 1, "35ac02e7fb00857f601c8b9a9c3fad17932cf2c7a301a2d0fedef61c350c911c") -- The Witcher 3 Wild Hunt - New Quest Fools Gold - The Witcher 3: Wild Hunt - Fool's Gold (376390) Depot
setManifestid(376390, "4380995726432289642", 101830135)
-- The Witcher 3 Wild Hunt - Ballad Heroes Neutral Gwent Card Set (AppID: 376391)
addappid(376391)
addappid(376391, 1, "a691c6929ba1ae81132b4baf31fd81cb87158c03e926d3310acf71d5a1286009") -- The Witcher 3 Wild Hunt - Ballad Heroes Neutral Gwent Card Set - The Witcher 3: Wild Hunt - 'Ballad Heroes' Neutral Gwent Card Set (376391) Depot
setManifestid(376391, "6437141662912268782", 931216)
-- The Witcher 3 Wild Hunt - New Quest Scavenger Hunt Wolf School Gear (AppID: 378640)
addappid(378640)
addtoken(378640, "8056110346062720087")
addappid(378640, 1, "13ddf115043ce87ceb0e52ec64938c102a665a483d48414db54425e52617cf35") -- The Witcher 3 Wild Hunt - New Quest Scavenger Hunt Wolf School Gear - Witcher 3: Wild Hunt DLC 11 (378640) Depot
setManifestid(378640, "5318422306227358494", 192475233)
-- The Witcher 3 Wild Hunt - Alternative Look for Triss (AppID: 378641)
addappid(378641)
addtoken(378641, "13137250378595674538")
addappid(378641, 1, "2a06dfffcdc645e88483b274bab505803dea0a498dcf0874efcca8d633b52c9d") -- The Witcher 3 Wild Hunt - Alternative Look for Triss - Witcher 3: Wild Hunt DLC 12 (378641) Depot
setManifestid(378641, "4647447917504831785", 12261078)
-- The Witcher 3 Wild Hunt - New Quest Contract Skelliges Most Wanted (AppID: 378642)
addappid(378642)
addappid(378642, 1, "8e82aa6c124304e5aafaf6319eb9cd5b84df9c2fd74f257f7936b58b7fa4a93e") -- The Witcher 3 Wild Hunt - New Quest Contract Skelliges Most Wanted - Witcher 3: Wild Hunt DLC 13 (378642) Depot
setManifestid(378642, "2210049775439183344", 148793864)
-- The Witcher 3 Wild Hunt - Skellige Armor Set (AppID: 378643)
addappid(378643)
addappid(378643, 1, "7165cd00ca2393e84e109e5f36ce0442707be4d472d573f9eecbea30c361f8de") -- The Witcher 3 Wild Hunt - Skellige Armor Set - Witcher 3: Wild Hunt DLC 14 (378643) Depot
setManifestid(378643, "459508221271235268", 64906002)
-- The Witcher 3 Wild Hunt - Alternative Look for Ciri (AppID: 378644)
addappid(378644)
addappid(378644, 1, "6f6e38d2efd42182a86e14afa5a2bf6f39c93e52fc173651a50e741c23379e15") -- The Witcher 3 Wild Hunt - Alternative Look for Ciri - Witcher 3: Wild Hunt DLC 15 (378644) Depot
setManifestid(378644, "2928442289493234239", 63093545)
-- The Witcher 3 Wild Hunt - New Quest Where the Cat and Wolf Play... (AppID: 378645)
addappid(378645)
addappid(378645, 1, "b7f1a0a26896dd7f0f9d29334b5439afd695df215ca63bfb2f118a203dc63130") -- The Witcher 3 Wild Hunt - New Quest Where the Cat and Wolf Play... - Witcher 3: Wild Hunt DLC 16 (378645) Depot
setManifestid(378645, "6056630807565191690", 153418702)
-- The Witcher 3 Wild Hunt - New Finisher Animations (AppID: 378646)
addappid(378646)
addappid(378646, 1, "7321f1ae7091f395e6f0854c10db5159d777bdc2697b9e6bd1f9ea74e218210a") -- The Witcher 3 Wild Hunt - New Finisher Animations - Witcher 3: Wild Hunt DLC 17 (378646) Depot
setManifestid(378646, "7313260968752741219", 1630016)
-- The Witcher 3 Wild Hunt - NEW GAME  (AppID: 378647)
addappid(378647)
addappid(378647, 1, "98e972b141076c8a6d72a292915cd5ef1d30eb73983070d8aa3f0aa77858f52a") -- The Witcher 3 Wild Hunt - NEW GAME  - Witcher 3: Wild Hunt DLC 18 (378647) Depot
setManifestid(378647, "6347498022277232982", 13516)
-- The Witcher 3 Wild Hunt - Blood and Wine (AppID: 378648)
addappid(378648)
addappid(378648, 1, "a3ef8bcc9af9edbd00aa55beadd796dfe0c980143c871b631291b05637113c1a") -- The Witcher 3 Wild Hunt - Blood and Wine - Witcher 3: Wild Hunt DLC 19 (378648) Depot
setManifestid(378648, "5677496677655330654", 9158782436)
addappid(310612, 1, "2778da309fe302e77a1578645da0f2f5cb1096822dab53c7ba456e829961d86f") -- The Witcher 3 Wild Hunt - Blood and Wine - EP2 Speech PL
setManifestid(310612, "5455214373061651405", 1126945645)
addappid(310613, 1, "e721336157973be351a375485bde985c8d5ad1821ef3d70f5072064c324309e8") -- The Witcher 3 Wild Hunt - Blood and Wine - EP2 Speech EN
setManifestid(310613, "2970969303001438150", 1061417259)
addappid(310614, 1, "41d483e998e4e5a4a256e08ea3cabde7c88cc81d0745015d064978b7f402ff07") -- The Witcher 3 Wild Hunt - Blood and Wine - EP2 Speech DE
setManifestid(310614, "1512711109507003050", 1065824219)
addappid(310615, 1, "23336e7ee6b781dd4b9b9e2f071dde6bbc19a6dbb03908a24aa02915d680ecef") -- The Witcher 3 Wild Hunt - Blood and Wine - EP2 Speech FR
setManifestid(310615, "8649692936145776844", 1068634963)
addappid(310616, 1, "49c227a33232cda12a88a053437fede2921516814540d309cf237e9e8404bc2f") -- The Witcher 3 Wild Hunt - Blood and Wine - EP2 Speech RU
setManifestid(310616, "81296909978179260", 1123992546)
addappid(310617, 1, "bd584800dd1556df065305414c425d43efd38b45fc614e722bfe5decd8f97bff") -- The Witcher 3 Wild Hunt - Blood and Wine - EP2 Speech JP
setManifestid(310617, "2115415390192780692", 1133887651)
addappid(310618, 1, "20293d6cbcec4b428015a68110d3055b8f5909f1e669d999baadcc8eb24b12dd") -- The Witcher 3 Wild Hunt - Blood and Wine - EP2 Speech BR
setManifestid(310618, "36196449033815259", 1071270623)
addappid(310619, 1, "1a710d9b03d4e5bbb6e1e57c0f3f322e52d2740b11803e4f718653b114af83ec") -- The Witcher 3 Wild Hunt - Blood and Wine - Blood and Wine extras
setManifestid(310619, "4855315366624356663", 654772037)
addappid(373954, 1, "32b895886f889ecad112d5bc901e501e5173ca081595b3adbf528bc111aac3c2") -- The Witcher 3 Wild Hunt - Blood and Wine - Depot 373954
setManifestid(373954, "9189601712632867387", 1105265034)
addappid(373955, 1, "118abd22ef378fd5c62d2205668aa8fc4d713c3ce5c22c8e952695d5c79c0723") -- The Witcher 3 Wild Hunt - Blood and Wine - Depot 373955
setManifestid(373955, "4126613168484560251", 1081305767)
-- The Witcher 3 Wild Hunt - Hearts of Stone  (AppID: 378649)
addappid(378649)
addappid(378649, 1, "7c934ed4aa4f0e7a1a5ea204d411bebf48377f7b7e6fa0a114d011107d04684b") -- The Witcher 3 Wild Hunt - Hearts of Stone  - Witcher 3: Wild Hunt DLC 20 (378649) Depot
setManifestid(378649, "9216322386755119484", 1787207628)
addappid(292043, 1, "eec6e98154b0e5cbc27742c27f9214034ac6ee649697ea9ecc087c7ec396f4ef") -- The Witcher 3 Wild Hunt - Hearts of Stone  - EP1 Speech PL
setManifestid(292043, "2863314232165890237", 425466201)
addappid(292044, 1, "f4b1aac8fe1d8c3d1b9fd4ed0766acc4be49037251cda4092b148ffbcb3422a9") -- The Witcher 3 Wild Hunt - Hearts of Stone  - EP1 Speech EN
setManifestid(292044, "908607634780300143", 401517780)
addappid(292045, 1, "cbf6ed38ba7e79ed057715f18ea171ba7f7bed4a6728285d204113558db7ff4a") -- The Witcher 3 Wild Hunt - Hearts of Stone  - EP1 Speech DE
setManifestid(292045, "4620621685241046742", 412579844)
addappid(292046, 1, "649d7f21dfad2ba0674aab102c196e6ac3c53780138773a693a06cabeece070e") -- The Witcher 3 Wild Hunt - Hearts of Stone  - EP1 Speech FR
setManifestid(292046, "1699589270478816105", 398083512)
addappid(292047, 1, "47e36cc0c65f98ee521bada7a7418b7cd7f67e873fb012eec08276ff331994b3") -- The Witcher 3 Wild Hunt - Hearts of Stone  - EP1 Speech RU
setManifestid(292047, "4188887637226014223", 412903504)
addappid(292048, 1, "c365f8a91132be9140d40aff760898195077139810cf6c0d1c1e7cf8845dbb02") -- The Witcher 3 Wild Hunt - Hearts of Stone  - EP1 Speech JP
setManifestid(292048, "5283427417482321933", 422183086)
addappid(292049, 1, "397dfb734f5a7b42a09b95f0c2d9cad324a1e34ddd9c0bc583c1bfb64c49dc85") -- The Witcher 3 Wild Hunt - Hearts of Stone  - EP1 Speech BR
setManifestid(292049, "7686086885054708771", 411803756)
addappid(310611, 1, "330dbf44f635b1b504b0bca11e0fc33fd8240e52f822083ef70cb65868c55b81") -- The Witcher 3 Wild Hunt - Hearts of Stone  - Hearts of Stone extras
setManifestid(310611, "9087403118674428852", 262696726)
addappid(373952, 1, "31a69f76a7088a6cb382e0ad8c5866456df9bcc8df53bacc9f878eb16af59c02") -- The Witcher 3 Wild Hunt - Hearts of Stone  - Depot 373952
setManifestid(373952, "7987515327562995934", 421245830)
addappid(373953, 1, "2b8b7f1f6d49cea5915d446c63860d74f36b43b1958a8da09df550a545a9e5dd") -- The Witcher 3 Wild Hunt - Hearts of Stone  - Depot 373953
setManifestid(373953, "2993703975089049690", 412240753)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(355880) -- The Witcher 3 Wild Hunt - Expansion Pass