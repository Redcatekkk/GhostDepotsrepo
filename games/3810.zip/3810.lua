-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 3810 Manifest
-- Name: BloodRayne
-- Generated: 2025-06-28 18:19:32
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3810) -- BloodRayne

-- MAIN APP DEPOTS
addappid(3811, 1, "3a818a8e22dbde320d2036c9b2155767929f631cf05719a02a449dc677445e3f") -- BloodRayne Content
setManifestid(3811, "5177721170901481981", 0)
