-- 3925760's Lua and Manifest Created by Morrenus
-- Unfair Flips
-- Created: October 17, 2025 at 15:46:36 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3925760) -- Unfair Flips
-- MAIN APP DEPOTS
addappid(3925761, 1, "bfd0da039adee38b88a9a8082aa7fc7eed37cdbb8959a01905de6da1df238d6c") -- Depot 3925761
setManifestid(3925761, "4283202914148437751", 89495060)