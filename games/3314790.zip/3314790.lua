-- 3314790's Lua and Manifest Created by Morrenus
-- CloverPit
-- Created: October 02, 2025 at 15:23:23 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3314790) -- CloverPit
-- MAIN APP DEPOTS
addappid(3314791, 1, "01f256d876a29ffa69ec7fefed5588393e85c3e5326497d7da92427e011759ff") -- Depot 3314791
setManifestid(3314791, "9018543576811044749", 366627615)