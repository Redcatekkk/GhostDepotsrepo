-- Generated Lua Manifest by Solus Bot in Morrenus Games!
-- Steam App 1273400 Manifest
-- Name: Construction Simulator
-- Generated: 2025-07-22 16:22:29
-- Total Depots: 19
-- Total DLCs: 19
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1273400) -- Construction Simulator

-- MAIN APP DEPOTS
addappid(1273401, 1, "7ac6b6d000ec93fdd41c708fdaa554b3b457d5e9c07bb1947f2d555502c12b28") -- Depot 1273401
setManifestid(1273401, "3680529257743237412", 0)

-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Construction Simulator - Car  Bobblehead Pack (AppID: 1944340)
addappid(1944340)
addappid(1944340, 1, "9ada72090f09e32fe5de61dc7f3d27dfa65bbf00c10951f5e171fef1d54467f4") -- Construction Simulator - Car  Bobblehead Pack - Depot 1944340
setManifestid(1944340, "322555549106022213", 0)

-- Construction Simulator - Customization Kit (AppID: 1944341)
addappid(1944341)
addappid(1944341, 1, "fff00853888f489491f77e33f4b0abfdb9e4f274f7abb2db7e4a473c75710ad2") -- Construction Simulator - Customization Kit - Depot 1944341
setManifestid(1944341, "8807678063382063768", 0)

-- Construction Simulator - Official Guide (AppID: 2153870)
addappid(2153870)
addappid(2153872, 1, "8d457689bea1359a61b8bc676238db49b96aec8e56ad39efd92741e9d2db04a6") -- Construction Simulator - Official Guide - Depot 2153872
setManifestid(2153872, "425545223924338255", 0)
-- addappid(2153871, 1, "MISSING_KEY") -- Construction Simulator - Official Guide - Depot 2153871 (no key available)

-- Construction Simulator - Kramer Pack (AppID: 2203420)
addappid(2203420)
addappid(2203420, 1, "936a535f06583e664a84071a3e5ef1442c263230dfccb079ed73cf6b1632531f") -- Construction Simulator - Kramer Pack - Depot 2203420
setManifestid(2203420, "8739100311331388793", 0)

-- Construction Simulator - JCB Pack (AppID: 2291420)
addappid(2291420)
addappid(2291424, 1, "aa1e4588ba76e6e1723d055f0ac651747fd4f70363d870bfd3bfcc0a9b0641d6") -- Construction Simulator - JCB Pack - Depot 2291424
setManifestid(2291424, "8453066766368453847", 0)

-- Construction Simulator - Airfield Expansion (AppID: 2295780)
addappid(2295780)
addappid(2295781, 1, "e934f73594337e0e6026594ced95237670b45cb3b0a4a8afe5afb168cf7c96b9") -- Construction Simulator - Airfield Expansion - Depot 2295781
setManifestid(2295781, "685349866155445181", 0)

-- Construction Simulator - SANY Pack (AppID: 2295810)
addappid(2295810)
addappid(2295811, 1, "81149cf5bfb357c4d5e9ca09e28b9bb871218513bf57671f45b4db19322e3987") -- Construction Simulator - SANY Pack - Depot 2295811
setManifestid(2295811, "3383914678723808175", 0)

-- Construction Simulator - Spaceport Expansion (AppID: 2295820)
addappid(2295820)
addappid(2295821, 1, "0238a85d92c1efd94f87882d80f94f274a9642622803775ac612597cc3900a37") -- Construction Simulator - Spaceport Expansion - Depot 2295821
setManifestid(2295821, "8580441773329478911", 0)

-- Construction Simulator - Cosmetic Pack 1 (AppID: 2322970)
addappid(2322970)
addappid(2322971, 1, "e259ebb0698e11fea131e2432dc3fb90a1deb703381e24c6f86da0a5b873260c") -- Construction Simulator - Cosmetic Pack 1 - Depot 2322971
setManifestid(2322971, "320280581201002583", 0)

-- Construction Simulator - Cosmetic Pack 2 (AppID: 2322980)
addappid(2322980)
addappid(2322981, 1, "5b18f6aa61fc834076274cf99d042aaf7a103e39ae6c2e916b2ca6c157969162") -- Construction Simulator - Cosmetic Pack 2 - Depot 2322981
setManifestid(2322981, "5743210225651998743", 0)

-- Construction Simulator - Year 1 Season Pass Helmet (AppID: 2322990)
addappid(2322990)
addappid(2322991, 1, "e6cef62d582f8932a2108656f1f9bd325b154bfbfd77bc4e334d201f50bd367f") -- Construction Simulator - Year 1 Season Pass Helmet - Depot 2322991
setManifestid(2322991, "7520794540910599885", 0)

-- Construction Simulator - Liebherr Pack (AppID: 2657380)
addappid(2657380)
addappid(2657381, 1, "1197196a9b63ed09d0fe34a639f3613f84174fd77cd34ebd8c94092c1618a6ef") -- Construction Simulator - Liebherr Pack - Depot 2657381
setManifestid(2657381, "6016383179637761921", 0)

-- Construction Simulator - Stadium Expansion (AppID: 2657390)
addappid(2657390)
addappid(2657391, 1, "57b63b80e8017b3ba57d81a99bf46013281784cf8337fae9f22c99188903283e") -- Construction Simulator - Stadium Expansion - Depot 2657391
setManifestid(2657391, "3197796519729678759", 0)

-- Construction Simulator - Dynapac Pack (AppID: 2657400)
addappid(2657400)
addappid(2657401, 1, "f4203866785afe4f52c192b96551976c3921fdb35b2b4c82cc2129b0d0a4f46c") -- Construction Simulator - Dynapac Pack - Depot 2657401
setManifestid(2657401, "8114831874000182204", 0)

-- Construction Simulator - DAF  MEILLER Pack (AppID: 2657410)
addappid(2657410)
addappid(2657411, 1, "6d0061174c36857cf29b71b91831fc9e2ae1d6b0e8e1095248975c2f7c29c28a") -- Construction Simulator - DAF  MEILLER Pack - Depot 2657411
setManifestid(2657411, "3557864438957203195", 0)

-- Construction Simulator - Year 2 Season Pass Pickup Truck (AppID: 2657420)
addappid(2657420)
addappid(2657421, 1, "44b4871b93c1c2532a5d33b57cba0f4741d9a76c64cb63c4678044b9d8eec00a") -- Construction Simulator - Year 2 Season Pass Pickup Truck - Depot 2657421
setManifestid(2657421, "8791015684642513912", 0)

-- Construction Simulator - Cosmetic Pack 3 (AppID: 2800780)
addappid(2800780)
addappid(2800781, 1, "e4fd402d9c5abf02cceaad103495cd1c30d7fe3c777d312788a808fe719e0701") -- Construction Simulator - Cosmetic Pack 3 - Depot 2800781
setManifestid(2800781, "5044123825545457794", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2323000) -- Construction Simulator - Year 1 Season Pass
addappid(2666240) -- Construction Simulator - Year 2 Season Pass
