-- 3121110's Lua and Manifest Created by Morrenus
-- Zort
-- Created: October 18, 2025 at 14:39:10 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 7
-- Total DLCs: 0
-- Shared Depots: 6

-- MAIN APPLICATION
addappid(3121110) -- Zort
-- MAIN APP DEPOTS
addappid(3121111, 1, "806aeaed5d4ad4428cd6c1eba28ff88c387605abe45508700508db278de71391") -- Depot 3121111
setManifestid(3121111, "881400566269157960", 5729691717)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
setManifestid(229000, "4622705914179893434", 242743889)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
setManifestid(229007, "4477590687906973371", 117381405)