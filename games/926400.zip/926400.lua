-- 926400's Lua and Manifest Created by Morrenus
-- Scatteria
-- Created: October 02, 2025 at 03:01:15 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(926400) -- Scatteria
-- MAIN APP DEPOTS
addappid(926401, 1, "85b5cd64744f3e7f8e5c4ea1ba47b800dcbe16507a8b841bed8f35b5367324e2") -- Scatteria Content
setManifestid(926401, "8812015574530676029", 186441409)