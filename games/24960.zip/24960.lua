-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 24960 Manifest
-- Name: Battlefield: Bad Company™ 2
-- Generated: 2025-06-04 23:38:44
-- Total Depots: 1
-- Total DLCs: 3

-- MAIN APPLICATION
addappid(24960) -- Battlefield: Bad Company™ 2

-- MAIN APP DEPOTS
addappid(24961, 1, "9900d08628ad2bf35a66c757bc3c82ebc93e898bfc25d9416d198aa9f8b7df89") -- battlefield_bc2_content
setManifestid(24961, "4081207827496872520", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(24962) -- Battlefield Bad Company 2 Promo Key (Preorder)
addappid(24963) -- Battlefield Bad Company 2 Specact Kit DLC
addappid(47880) -- Battlefield Bad Company 2 Vietnam
