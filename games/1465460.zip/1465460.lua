-- 1465460's Lua and Manifest Created by Morrenus
-- Infection Free Zone
-- Created: October 18, 2025 at 08:38:27 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0 (1 excluded)

-- MAIN APPLICATION
addappid(1465460, 1, "86d798c9de12740c68e9f88ad9799466c2fa68547751f1ed7778a246b696742a") -- Infection Free Zone
-- MAIN APP DEPOTS
addappid(1465461, 1, "e2a62ed18d9479e7bca56d425a8c527bacdfc7435666810eafeea55fe3e7746f") -- Depot 1465461
setManifestid(1465461, "175368280147702492", 6061951038)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Infection Free Zone - Supporter Pack (AppID: 3905440) - missing depot keys
-- addappid(3905440)