-- 397950's Lua and Manifest Created by Morrenus
-- Clustertruck
-- Created: September 29, 2025 at 04:38:48 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(397950, 1, "79c90fbd0df92e14dae5541a5d32e36b710b3a0e1732806ead67e43fe250db12") -- Clustertruck
-- MAIN APP DEPOTS
addappid(397951, 1, "de9ce3a3453e17c9e0c42708f09ab4331933ba21745754536d182a0bfb194c57") -- ClusterTruck Content
setManifestid(397951, "285661690570693680", 475483523)
addappid(397952, 1, "92a7a241a50c36c21d18be55b3fd45dc7d533b1319438d4239dcc7d549f124f6") -- ClusterTruck mac
setManifestid(397952, "3065561030180530109", 487177349)
addappid(397953, 1, "c083ab03aaa582199d22f2efbd6331a23bd0b8546c5bbb31631cb496c789d0eb") -- ClusterTruck linux
setManifestid(397953, "4029228013093482524", 485228798)
addappid(397954, 1, "8d2a77f0e2e9849987bd78605e53ee19fafb62ed4122c022c0cb15fad155553f") -- Clustertruck mac64
setManifestid(397954, "3581507225628136631", 484311732)