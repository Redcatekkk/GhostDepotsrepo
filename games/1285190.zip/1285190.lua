-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1285190)
addappid(1285192,0,"3e212ce90691e4e8f2f1418c35495c50a725bb0d012d9f415b0a8a9119dfb0f4")
setManifestid(1285192,"1984823441859390005")